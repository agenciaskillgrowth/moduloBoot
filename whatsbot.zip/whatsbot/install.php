<?php

defined('BASEPATH') || exit('No direct script access allowed');

$CI = &get_instance();

// Adicionar token de verificação padrão, se necessário
add_option('wac_verify_token', app_generate_hash());

// Iniciar transação para consistência
$CI->db->trans_start();

// Função para garantir a criação de tabelas
function ensure_table_exists($table_name, $create_query)
{
    $CI = &get_instance();
    if (!$CI->db->table_exists(db_prefix() . $table_name)) {
        $CI->db->query($create_query);
    }
}

// Função para alterar tabelas existentes
function alter_table_if_field_missing($table_name, $field_name, $alter_query)
{
    $CI = &get_instance();
    if ($CI->db->table_exists(db_prefix() . $table_name)) {
        if (!$CI->db->field_exists($field_name, db_prefix() . $table_name)) {
            $CI->db->query($alter_query);
        }
    }
}

// Criar tabelas
ensure_table_exists('wtc_bot', '
    CREATE TABLE `' . db_prefix() . 'wtc_bot` (
        `id` int NOT NULL AUTO_INCREMENT,
        `name` varchar(255) NOT NULL,
        `rel_type` varchar(50) NOT NULL,
        `reply_text` text NOT NULL,
        `reply_type` int NOT NULL,
        `trigger` text,
        `bot_header` varchar(65) DEFAULT NULL,
        `bot_footer` varchar(65) DEFAULT NULL,
        `button1` varchar(25) DEFAULT NULL,
        `button1_id` varchar(258) DEFAULT NULL,
        `button2` varchar(25) DEFAULT NULL,
        `button2_id` varchar(258) DEFAULT NULL,
        `button3` varchar(25) DEFAULT NULL,
        `button3_id` varchar(258) DEFAULT NULL,
        `button_name` varchar(25) DEFAULT NULL,
        `button_url` varchar(255) DEFAULT NULL,
        `filename` text DEFAULT NULL,
        `addedfrom` int NOT NULL,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `is_bot_active` tinyint(1) NOT NULL DEFAULT "1",
        `sending_count` int DEFAULT "0",
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=' . $CI->db->char_set . ';'
);

ensure_table_exists('wtc_templates', '
    CREATE TABLE `' . db_prefix() . 'wtc_templates` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `template_id` BIGINT UNSIGNED NOT NULL COMMENT "id from api",
        `template_name` VARCHAR(255) NOT NULL,
        `language` VARCHAR(50) NOT NULL,
        `status` VARCHAR(50) NOT NULL,
        `category` VARCHAR(100) NOT NULL,
        `header_data_format` VARCHAR(10) NOT NULL,
        `header_data_text` TEXT,
        `header_params_count` INT NOT NULL,
        `body_data` TEXT NOT NULL,
        `body_params_count` INT NOT NULL,
        `footer_data` TEXT,
        `footer_params_count` INT NOT NULL,
        `buttons_data` TEXT NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `template_id` (`template_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=' . $CI->db->char_set . ';'
);

ensure_table_exists('wtc_campaigns', '
    CREATE TABLE `' . db_prefix() . 'wtc_campaigns` (
        `id` int NOT NULL AUTO_INCREMENT,
        `name` varchar(100) NOT NULL,
        `rel_type` varchar(50) NOT NULL,
        `template_id` int DEFAULT NULL,
        `scheduled_send_time` timestamp NULL DEFAULT NULL,
        `send_now` tinyint NOT NULL DEFAULT "0",
        `header_params` text,
        `body_params` text,
        `footer_params` text,
        `filename` text DEFAULT NULL,
        `pause_campaign` tinyint(1) NOT NULL DEFAULT "0",
        `select_all` tinyint(1) NOT NULL DEFAULT "0",
        `trigger` text,
        `bot_type` int NOT NULL DEFAULT 0,
        `is_bot_active` int NOT NULL DEFAULT 1,
        `is_bot` int NOT NULL DEFAULT 0,
        `is_sent` tinyint(1) NOT NULL DEFAULT "0",
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `sending_count` int DEFAULT "0",
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=' . $CI->db->char_set . ';'
);

// Alterar tabelas, se necessário
alter_table_if_field_missing('wtc_templates', 'buttons_data', '
    ALTER TABLE `' . db_prefix() . 'wtc_templates` CHANGE `buttons_data` `buttons_data` TEXT NOT NULL;
');

alter_table_if_field_missing('wtc_campaigns', 'rel_data', '
    ALTER TABLE `' . db_prefix() . 'wtc_campaigns` ADD `rel_data` TEXT NULL DEFAULT NULL;
');

// Completar transação
$CI->db->trans_complete();

// Verificar se houve erros durante a transação
if ($CI->db->trans_status() === FALSE) {
    log_message('error', 'Erro ao criar ou alterar tabelas para o módulo WhatsBot');
    show_error('Erro ao configurar o banco de dados para o módulo. Verifique os logs para mais detalhes.');
} else {
    log_message('info', 'Tabelas do módulo WhatsBot criadas ou atualizadas com sucesso.');
}

?>
