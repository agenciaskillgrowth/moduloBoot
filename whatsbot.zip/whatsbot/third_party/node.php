<?php

if (!defined('WB_REG_PROD_POINT')) {
    define('WB_REG_PROD_POINT', 'https://api.corbitaltech.dev/api/v2/register');
}
if (!defined('WB_VAL_PROD_POINT')) {
    define('WB_VAL_PROD_POINT', 'https://api.corbitaltech.dev/api/v2/validate');
}
if (!defined('WB_GIVE_ME_CODE')) {
    define('WB_GIVE_ME_CODE', 'https://api.corbitaltech.dev/api/v2/givemecode');
}
