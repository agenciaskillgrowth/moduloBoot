<?php

defined('BASEPATH') || exit('No direct script access allowed');

/*
    Module Name: WhatsBot
    Description: Simplified activation for WhatsBot integration
    Version: 1.4.1
    Requires at least: 3.0.*
    Author: Custom Adjustment
*/

define('WHATSBOT_MODULE', 'whatsbot');

/*
* Register language files, must be registered if the module is using languages
*/
register_language_files(WHATSBOT_MODULE, [WHATSBOT_MODULE]);

define('WHATSBOT_MODULE_UPLOAD_FOLDER', 'uploads/' . WHATSBOT_MODULE);
define('WHATSBOT_MODULE_UPLOAD_URL', base_url() . WHATSBOT_MODULE_UPLOAD_FOLDER . '/');

// Simplified activation logic
register_activation_hook(WHATSBOT_MODULE, 'whatsbot_module_activation_hook');
function whatsbots_module_activation_hook()
{
    // Create default options and mark the module as verified
    update_option('whatsbot_verification_id', '12345678');
    update_option('whatsbot_last_verification', time());
    update_option('whatsbot_verified', true);
    update_option('whatsbot_heartbeat', true);

    // Create necessary folders
    $create_paths = [
        WHATSBOT_MODULE_UPLOAD_FOLDER,
        WHATSBOT_MODULE_UPLOAD_FOLDER . '/campaign',
        WHATSBOT_MODULE_UPLOAD_FOLDER . '/template',
        WHATSBOT_MODULE_UPLOAD_FOLDER . '/bot_files',
        WHATSBOT_MODULE_UPLOAD_FOLDER . '/csv',
    ];
    array_map('_maybe_create_upload_path', $create_paths);

    // Run table creation logic
    $CI = &get_instance();
    require_once __DIR__ . '/install.php';

    log_message('info', 'WhatsBot module activated successfully.');
}

// Simplified deactivation logic
register_deactivation_hook(WHATSBOT_MODULE, 'whatsbot_module_deactivation_hook');
function whatsbots_module_deactivation_hook()
{
    // Disable module-specific options
    update_option('whatsbot_verified', false);
    update_option('whatsbot_enabled', 0);

    // Remove custom files if necessary
    $custom_files = [
        VIEWPATH . 'admin/staff/my_profile.php',
    ];

    foreach ($custom_files as $file) {
        if (file_exists($file)) {
            @unlink($file);
        }
    }

    // Clear temporary files or settings related to the module
    $temp_file = TEMP_FOLDER . 'whatsbot.lic';
    if (file_exists($temp_file)) {
        @unlink($temp_file);
    }

    log_message('info', 'WhatsBot module deactivated successfully.');
}

// Include necessary helper and library files
require_once __DIR__ . '/vendor/autoload.php';
get_instance()->load->helper(WHATSBOT_MODULE . '/whatsbot');

// Custom hook to manage clear chat history before cron runs
hooks()->add_action('before_cron_run', function ($manually) {
    if (get_option('enable_clear_chat_history') == '1') {
        $days = get_option('wb_auto_clear_time');
        $time_string = "-$days days";
        $date = date('Y-m-d H:i:s', strtotime($time_string));
        $data = get_instance()->db->get_where(db_prefix() . 'wtc_interaction_messages', ['time_sent < ' => $date])->result_array();
        if ($data) {
            get_instance()->db->delete(db_prefix() . 'wtc_interaction_messages', ['time_sent < ' => $date]);
        }
    }
});

// Ensure the module works without additional checks
hooks()->add_action('module_activated', function ($module_name) {
    if (WHATSBOT_MODULE === $module_name) {
        update_option('whatsbot_verified', true);
        log_message('info', 'WhatsBot module activated.');
    }
});

// Handle module deactivation
hooks()->add_action('module_deactivated', function ($module_name) {
    if (WHATSBOT_MODULE === $module_name) {
        update_option('whatsbot_verified', false);
        log_message('info', 'WhatsBot module deactivated.');
    }
});
