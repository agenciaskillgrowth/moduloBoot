<?php

$config['openai_models'] = [
    [
        'key' => 'gpt-3.5-turbo',
        'value' => 'GPT-3.5-turbo'
    ],
    [
        'key' => 'gpt-4',
        'value' => 'GPT-4'
    ],
    [
        'key' => 'gpt-4-turbo-preview',
        'value' => 'GPT-4-turbo-preview'
    ],
    [
        'key' => 'gpt-4-0125-preview',
        'value' => 'GPT-4-0125-preview'
    ]
];
